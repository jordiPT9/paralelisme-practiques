package p02_ImpLockTable;

import p00_CommonA.Table;

public class ImplicitLockTable extends Table{
	
	/* Declare and initialize tour simple-typed variables here */

	protected void gainExclusiveAccess() {
		/* COMPLETE */
	}


	protected void releaseExclusiveAccess() {
		/* COMPLETE */
	}


	public void putJack(int id) {
		/* COMPLETE */
	}

	
	public void putQueen(int id) {
		/* COMPLETE */
	}

	
	public void putKing(int id) {
		/* COMPLETE */
	}


	public void cardPut() {
		/* COMPLETE */
	}

	
	public void startCheck(int id) {
		/* COMPLETE */
	}

	
	public void endCheck(int id) {
		/* COMPLETE */
	}

}
