package p01_MutexTable;

import java.util.concurrent.Semaphore;

import p00_CommonA.Table;

public class MutexTable extends Table{

	
	/* Declare and initialize your semaphore here */
	
	protected void gainExclusiveAccess () {
		/* COMPLETE */
	}
	
	protected void releaseExclusiveAccess() {
		/* COMPLETE */
	}
	
	
	public void putJack(int id) {
		/* COMPLETE */
	}
	
	public void putQueen(int id) {
		/* COMPLETE */
		
	}
	
	public void putKing(int id) {
		/* COMPLETE */
		
	}

	
	public void startCheck(int id) {
		/* COMPLETE */
	}

	
	public void endCheck(int id) {
		/* COMPLETE */
	}

	
	public void cardPut() {
		/* COMPLETE */
	}

}
